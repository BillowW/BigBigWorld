import list from '../../config';

Component({
  data: {
    list,
  },
});
