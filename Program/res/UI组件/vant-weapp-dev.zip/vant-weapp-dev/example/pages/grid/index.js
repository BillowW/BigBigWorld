import Page from '../../common/page';

Page({
  data: {
    array3: [0, 1, 2],
    array4: [0, 1, 2, 3],
    array6: [0, 1, 2, 3, 4, 5],
    array8: [0, 1, 2, 3, 4, 5, 6, 7],
  },
});
